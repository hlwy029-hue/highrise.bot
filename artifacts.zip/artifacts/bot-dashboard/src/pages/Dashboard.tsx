import { 
  useGetBotStatus, 
  getGetBotStatusQueryKey, 
  useGetBotStats, 
  getGetBotStatsQueryKey 
} from "@workspace/api-client-react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { motion } from "framer-motion";
import { Users, Clock, Activity, Command as CommandIcon, Music, Zap, ExternalLink, MapPin, Copy, Check } from "lucide-react";
import { useState } from "react";

const BASE = import.meta.env.BASE_URL.replace(/\/$/, "");

type Position = { x: number; y: number; z: number; facing: string; ts: number };
type Positions = Record<string, Position>;

function usePositions() {
  return useQuery<{ positions: Positions }>({
    queryKey: ["bot-positions"],
    queryFn: () => fetch(`${BASE}/api/bot/positions`).then(r => r.json()),
    refetchInterval: 3000,
  });
}

export default function Dashboard() {
  const { data: status, isLoading: isStatusLoading } = useGetBotStatus({
    query: {
      refetchInterval: 10000,
      queryKey: getGetBotStatusQueryKey()
    }
  });

  const { data: stats, isLoading: isStatsLoading } = useGetBotStats({
    query: {
      refetchInterval: 30000,
      queryKey: getGetBotStatsQueryKey()
    }
  });

  const { data: posData } = usePositions();
  const positions = posData?.positions ?? {};
  const posEntries = Object.entries(positions).sort((a, b) => b[1].ts - a[1].ts);

  const commands = [
    "الحق @user", "توقف", "هزو", "نزلني", "فوق", "فوك", "صعدني", 
    "vip", "vip @user", "vvip", "vvip @user", "جيب @user", 
    "اطرد @user", "حظر @user", "بلوك @user", "ميوت @user"
  ];

  return (
    <div className="min-h-[100dvh] w-full p-4 md:p-8 lg:p-12 relative overflow-hidden">
      <div className="absolute top-[-20%] right-[-10%] w-[50%] h-[50%] rounded-full bg-primary/10 blur-[120px] pointer-events-none" />
      <div className="absolute bottom-[-20%] left-[-10%] w-[50%] h-[50%] rounded-full bg-secondary/10 blur-[120px] pointer-events-none" />

      <div className="max-w-6xl mx-auto space-y-8 relative z-10">
        
        {/* Header */}
        <header className="flex flex-col md:flex-row items-start md:items-center justify-between gap-6 pb-6 border-b border-border/50">
          <div className="space-y-2">
            <div className="flex items-center gap-4">
              <motion.h1 
                initial={{ opacity: 0, y: -20 }}
                animate={{ opacity: 1, y: 0 }}
                className="text-5xl md:text-7xl font-bold tracking-tight neon-text text-white"
              >
                9.__
              </motion.h1>
              {isStatusLoading ? (
                <Skeleton className="h-8 w-24 rounded-full" />
              ) : (
                <Badge 
                  variant={status?.online ? "default" : "destructive"}
                  className={`text-sm px-4 py-1 flex items-center gap-2 ${status?.online ? 'bg-green-500/20 text-green-400 border-green-500/50' : ''}`}
                >
                  <span className={`w-2 h-2 rounded-full ${status?.online ? 'bg-green-400 status-dot-online' : 'bg-destructive'}`} />
                  {status?.online ? "متصل" : "غير متصل"}
                </Badge>
              )}
            </div>
            <p className="text-muted-foreground text-lg flex items-center gap-2">
              <span className="font-mono text-primary/80">696db8cb135ecd6d9ecf77e6</span>
              <span className="text-sm border border-border px-2 rounded bg-muted/50">معرف الغرفة</span>
            </p>
          </div>

          <a 
            href="https://high.rs/world?id=6894bd39e3e4a405517cb530&ownedRoomId=696db8cb135ecd6d9ecf77e6"
            target="_blank"
            rel="noopener noreferrer"
            className="group flex items-center gap-2 bg-primary/10 hover:bg-primary/20 border border-primary/30 text-primary-foreground px-6 py-3 rounded-full transition-all duration-300 hover:glow-effect"
          >
            <span>زيارة الغرفة</span>
            <ExternalLink className="w-4 h-4 transition-transform group-hover:-translate-y-1 group-hover:translate-x-1" />
          </a>
        </header>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <StatCard title="مدة التشغيل" value={status?.uptime} icon={Clock} loading={isStatusLoading} delay={0.1} />
          <StatCard title="المستخدمين" value={status?.userCount} icon={Users} loading={isStatusLoading} delay={0.2} />
          <StatCard title="إجمالي الدخول" value={stats?.totalJoins} icon={Activity} loading={isStatsLoading} delay={0.3} />
          <StatCard title="الرقصات المرسلة" value={stats?.totalDancesSent} icon={Music} loading={isStatsLoading} delay={0.4} />
        </div>

        {/* Position Tracker */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.45 }}
        >
          <Card className="bg-card/50 backdrop-blur border-primary/30 neon-border">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-2xl">
                <MapPin className="w-6 h-6 text-primary" />
                <span>إحداثيات المستخدمين</span>
                <Badge variant="outline" className="text-xs font-mono mr-auto">
                  يتحدث كل 3 ثوان
                </Badge>
              </CardTitle>
              <CardDescription>
                إحداثيات كل شخص في الغرفة — انسخ القيم واستخدمها في أوامر الانتقال
              </CardDescription>
            </CardHeader>
            <CardContent>
              {posEntries.length === 0 ? (
                <div className="flex flex-col items-center justify-center py-12 text-muted-foreground gap-3">
                  <MapPin className="w-12 h-12 opacity-20" />
                  <p className="text-sm">في انتظار تحرك المستخدمين في الغرفة…</p>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-3">
                  {posEntries.map(([username, pos]) => (
                    <PositionCard key={username} username={username} pos={pos} />
                  ))}
                </div>
              )}

              <div className="mt-6 p-4 bg-primary/5 border border-primary/20 rounded-lg">
                <div className="flex items-start gap-3">
                  <Zap className="w-5 h-5 text-secondary mt-0.5 shrink-0" />
                  <div className="text-sm text-muted-foreground" dir="rtl">
                    انسخ الإحداثيات واستبدل القيم في كود أوامر مثل{" "}
                    <code className="bg-muted px-1.5 py-0.5 rounded font-mono text-primary text-xs">
                      Position(x='14.0', y='0.25', z='17.0')
                    </code>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Commands & Performance */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 pt-4">
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5 }}
            className="lg:col-span-2"
          >
            <Card className="bg-card/50 backdrop-blur border-primary/20 h-full neon-border">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-2xl">
                  <CommandIcon className="w-6 h-6 text-primary" />
                  <span>دليل الأوامر</span>
                </CardTitle>
                <CardDescription>جميع الأوامر المتاحة للبوت في الغرفة</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex flex-wrap gap-3">
                  {commands.map((cmd, i) => (
                    <div 
                      key={i} 
                      className="bg-muted border border-border rounded-md px-4 py-2 font-mono text-sm text-foreground/90 hover:border-primary/50 transition-colors"
                      dir="ltr"
                    >
                      {cmd}
                    </div>
                  ))}
                </div>
                <div className="mt-8 p-4 bg-primary/5 border border-primary/20 rounded-lg">
                  <div className="flex items-start gap-3">
                    <Zap className="w-5 h-5 text-secondary mt-0.5" />
                    <div>
                      <h4 className="font-semibold text-lg text-foreground mb-1">الأرقام (الرقصات)</h4>
                      <p className="text-muted-foreground text-sm">
                        اكتب أي رقم من <span className="font-mono text-primary">1</span> إلى <span className="font-mono text-primary">95</span> في الدردشة لتفعيل رقصة معينة.
                      </p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.6 }}
          >
            <Card className="bg-card/50 backdrop-blur border-border h-full">
              <CardHeader>
                <CardTitle className="text-xl">ملخص الأداء</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">إجمالي الأوامر</span>
                    <span className="font-mono text-primary font-bold">
                      {isStatsLoading ? "..." : stats?.totalCommands?.toLocaleString() || "0"}
                    </span>
                  </div>
                  <div className="h-2 bg-muted rounded-full overflow-hidden">
                    <motion.div 
                      className="h-full bg-primary" 
                      initial={{ width: 0 }}
                      animate={{ width: "100%" }}
                      transition={{ duration: 1, delay: 0.8 }}
                    />
                  </div>
                </div>
                <div className="pt-6 border-t border-border/50">
                  <p className="text-xs text-muted-foreground text-center">
                    يتم تحديث البيانات تلقائياً للحفاظ على المزامنة في الوقت الفعلي
                  </p>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </div>
      </div>
    </div>
  );
}

function PositionCard({ username, pos }: { username: string; pos: Position }) {
  const [copied, setCopied] = useState(false);

  const coordText = `x='${pos.x}', y='${pos.y}', z='${pos.z}'`;

  const handleCopy = () => {
    navigator.clipboard.writeText(coordText);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const age = Math.round((Date.now() / 1000 - pos.ts));
  const ageLabel = age < 60 ? `منذ ${age}ث` : `منذ ${Math.round(age / 60)}د`;

  return (
    <div className="group relative bg-muted/40 border border-border/60 hover:border-primary/40 rounded-xl p-4 transition-all duration-200">
      <div className="flex items-center justify-between mb-3">
        <span className="font-semibold text-sm text-foreground truncate max-w-[140px]" dir="ltr">
          @{username}
        </span>
        <span className="text-xs text-muted-foreground">{ageLabel}</span>
      </div>

      <div className="grid grid-cols-3 gap-2 mb-3">
        {(["x", "y", "z"] as const).map(axis => (
          <div key={axis} className="bg-background/60 rounded-lg px-2 py-1.5 text-center">
            <div className="text-xs text-muted-foreground uppercase font-medium">{axis}</div>
            <div className="font-mono text-sm text-primary font-bold">{pos[axis]}</div>
          </div>
        ))}
      </div>

      {pos.facing && (
        <div className="text-xs text-muted-foreground mb-3 font-mono" dir="ltr">
          facing: {pos.facing}
        </div>
      )}

      <button
        onClick={handleCopy}
        className="w-full flex items-center justify-center gap-2 bg-primary/10 hover:bg-primary/20 border border-primary/30 text-primary text-xs py-1.5 rounded-lg transition-all duration-200"
      >
        {copied ? (
          <>
            <Check className="w-3.5 h-3.5" />
            <span>تم النسخ!</span>
          </>
        ) : (
          <>
            <Copy className="w-3.5 h-3.5" />
            <span>نسخ الإحداثيات</span>
          </>
        )}
      </button>
    </div>
  );
}

function StatCard({ 
  title, value, icon: Icon, loading, delay 
}: { 
  title: string; value: string | number | undefined; icon: any; loading: boolean; delay: number;
}) {
  return (
    <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} transition={{ delay }}>
      <Card className="bg-card/40 backdrop-blur border-border/50 hover:border-primary/30 transition-colors group overflow-hidden relative">
        <div className="absolute top-0 right-0 p-4 opacity-5 group-hover:opacity-10 transition-opacity">
          <Icon className="w-24 h-24" />
        </div>
        <CardContent className="p-6 relative z-10 flex flex-col gap-4">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-primary/10 rounded-lg text-primary">
              <Icon className="w-5 h-5" />
            </div>
            <p className="text-sm font-medium text-muted-foreground">{title}</p>
          </div>
          <div>
            {loading ? (
              <Skeleton className="h-10 w-2/3" />
            ) : (
              <p className="text-3xl font-bold font-mono tracking-tight">
                {value !== undefined ? value : "—"}
              </p>
            )}
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}
