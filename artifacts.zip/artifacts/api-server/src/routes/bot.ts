import { Router, type IRouter } from "express";
import { GetBotStatusResponse, GetBotStatsResponse } from "@workspace/api-zod";

const router: IRouter = Router();

const startTime = Date.now();

// In-memory stats shared with bot process via env or defaults
let botStats = {
  online: true,
  userCount: 0,
  totalJoins: 0,
  totalDancesSent: 0,
  totalCommands: 0,
};

router.get("/bot/status", (req, res) => {
  const uptimeSecs = Math.floor((Date.now() - startTime) / 1000);
  const h = Math.floor(uptimeSecs / 3600);
  const m = Math.floor((uptimeSecs % 3600) / 60);
  const s = uptimeSecs % 60;
  const uptime = `${String(h).padStart(2, "0")}:${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;

  const data = GetBotStatusResponse.parse({
    online: botStats.online,
    roomId: "696db8cb135ecd6d9ecf77e6",
    botName: "9.__",
    uptime,
    userCount: botStats.userCount,
  });
  res.json(data);
});

router.get("/bot/stats", (req, res) => {
  const data = GetBotStatsResponse.parse({
    totalJoins: botStats.totalJoins,
    totalDancesSent: botStats.totalDancesSent,
    totalCommands: botStats.totalCommands,
    startTime: new Date(startTime).toISOString(),
  });
  res.json(data);
});

export default router;
